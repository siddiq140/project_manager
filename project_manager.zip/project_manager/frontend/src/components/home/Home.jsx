import Sidebar from "../sidebar/Sidebar";

const Home = () => {
   return (
      <div>
         <Sidebar />
      </div>
   );
};

export default Home;
